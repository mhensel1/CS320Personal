var app = require('express')();
const http = require('http').createServer(app);
const mysql = require('mysql2');
const prompt = require("prompt-sync")();
var io = require('socket.io')(http);

//var song_name = speech();

const pool = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: 'locks524',
  database: 'songify1_db',
  charset: 'utf8'
});

var reo = '';
var reoFail = '';

//sets and returns html table with results from sql select
//Receives sql query and callback function to return the table

function setResHtml(sql, tem, cb){
  if (tempo_real != '0'){
  pool.getConnection((err, con)=>{
    if(err) throw err;
    con.query(sql, (err, res, cols)=>{
     	 if(err) throw err;
     	 var table =''; //to store html table
	 var len = ''; 
	 var space = ' ';
	 if (tempo_real.length >= res.length && tempo_real.length >= keese.length){
		len = tempo_real.length;	
	 } 
	 else if (keese.length >= res.length && keese.length >= tempo_real.length){
		len = keese.length;
	 } else len = res.length;

    	  //create html table with data from res.
	 table += '<p>'+space+ 'Album: '+ alb_name +', Tempo: '+ sped +', Key: '+ keynote +'</p>';
     	 for(var i=0; i<len; i++){
	   if (i >= tempo_real.length && i < res.length && i < keese.length){
		table +='<tr><td>'+ (i+1) +'</td><td>'+ res[i].name +'</td><td>'+ space +'</td> <td>'+ keese[i].name +'</td></tr>';
	   }
     	   else if (i >= res.length && i < tempo_real.length && i < keese.length){
		table +='<tr><td>'+ (i+1) +'</td><td>'+ space +'</td><td>'+ tempo_real[i].name +'</td> <td>'+ keese[i].name +'</td></tr>';
	   }
	   else if (i >= keese.length && i < res.length && i < tempo_real.length){
		table +='<tr><td>'+ (i+1) +'</td><td>'+ res[i].name +'</td><td>'+ tempo_real[i].name +'</td> <td>'+ space +'</td></tr>';
	   }
	   else if (i >= res.length && i >= keese.length){
		table +='<tr><td>'+ (i+1) +'</td><td>'+ space +'</td><td>'+ tempo_real[i].name +'</td><td>'+ space +'</td></tr>';
	   }
	   else if (i >= res.length && i >= tempo_real.length){
		table +='<tr><td>'+ (i+1) +'</td><td>'+ space +'</td><td>'+ space +'</td><td>'+ keese[i].name +'</td></tr>';
	   }
	   else if (i >= keese.length && i >= tempo_real.length){
		table +='<tr><td>'+ (i+1) +'</td><td>'+ res[i].name +'</td><td>'+ space +'</td><td>'+ space +'</td></tr>';
	   }else table +='<tr><td>'+ (i+1) +'</td><td>'+ res[i].name +'</td><td>'+ tempo_real[i].name +'</td><td>'+ keese[i].name +'</td></tr>';
     	 }
     	 table ='<table border="0"><tr><th>No.</th><th>Songs by Album</th><th> Songs by Tempo</th><th> Songs by Key</th></tr>'+ table +'</table>';

     	 con.release(); //Done with mysql connection
	 http.close();
	 console.log('server closed');
     	 return cb(table);
     });
    
  });			//html table contruction
  } 
  else{
	var table = '';
	var space = ' ';
	table += '<p>Entry Not Found in the Database</p>';
	table +='<tr><td>'+ space +'</td><td>'+ space +'</td><td>'+ space +'</td> <td>'+ space +'</td></tr>';
	table ='<table border="0"><tr><th>'+space+'</th><th>'+space+'</th><th>'+space+'</th><th>'+space+'</th></tr>'+ table +'</table>';
	http.close();
	console.log('server closed');
     	return cb(table);
  }
}

var song_name = [];
var tempo_real = '0';
var browsetime = function sqlbrowser(song) {
//var song_name = prompt("Pick an Song: ");
song_name = song;		//global vars
var alb_name = [];
var songql ='SELECT album FROM songs WHERE name ='+mysql.escape(song_name)+'';
sql ='SELECT name FROM songs WHERE album = '+mysql.escape(song_name)+' ORDER BY name';
var keese = [];
tempo_real = '0';
reo ='';
var keynote = [];


pool.getConnection((err, con)=>{
    	if (err) throw err;
    	con.query(songql, (err, result)=>{
		if (result[0] == null) {
			console.log("Song not in database!");
			toBrowser(0);
			con.release();
		}
		else {getAlbSongs(result[0].album);}
		con.release();
    	});
});
}
module.exports = browsetime

function getAlbSongs(value){		//database queries
	alb_name = value;
	pool.getConnection((err, con)=>{
    		if (err) throw err;
    		con.query("SELECT bpm from songs WHERE name = " + mysql.escape(song_name), function (err, beats) {
			if (err) throw err;
			getBpmSongs(beats[0].bpm);
		});
		con.query("SELECT notekey FROM songs WHERE name = " +mysql.escape(song_name), function(err, theKey) {
			if (err) throw err;
			getKeySongs(theKey[0].notekey);
		});
		con.release();
	});
	sql ='SELECT name FROM songs WHERE album = '+mysql.escape(alb_name)+' ORDER BY name';
}

function getKeySongs(v){
	keynote = v;
	keyql = 'SELECT name FROM songs WHERE notekey = ' + mysql.escape(keynote)+' ORDER BY name';
	pool.getConnection((err, con)=>{
		con.query(keyql, (err, result)=>{
			if (err) throw err;
			keese = result;
			con.release();
		});
	});
}

function getBpmSongs(val){
	sped = val;
	var low = Number(sped) - 5;
	var high = Number(sped) + 5;
	bpmsql ='SELECT name FROM songs WHERE bpm BETWEEN ' + mysql.escape(low) +' AND ' + mysql.escape(high)+' ORDER BY name';
	pool.getConnection((err, con)=>{
		con.query(bpmsql, (err, reso)=>{
			if (err) throw err;
			tempo_real= reso;
			toBrowser(reso);
			con.release();
    		});
	});
	
}

function toBrowser(temp){		//server launch
//create the server for browser access
	var tempo = temp;

//html string that will be sent to browser
reo ='<html><head><title>Songify Similars</title><style>body{background-image: url("https://cdn.wallpapersafari.com/71/68/xobmAV.jpg");} table{border: 8px solid black; font-size: 25px; margin-left:auto; margin-right:auto; border-color: #00b5ff; border-radius: 25px;} table th{text-align:center; background-color: #00b5ff; border: 0px solid #ddd;} table td{text-align:center; background-color: #00b5ff; border: 0px solid #ddd} p{padding: 5px; border-style: solid; border-color: #fff; border-radius: 8px; text-align:center; font-size: 25px; color: blue; background-color: #ffc800;} button{border-radius: 12px; font-size: 24px; background-color: #008CBA; color: #fff; font-family: "Trebuchet MS", sans-serif;}</style></head><body><h1 style="color:blue; text-align: center; font-size: 50px;">Similar Songs</h1><form id="back" action="http://localhost:3000/home" method=GET"><button id="BackToHome"> Back</button></form>{${table}}</body></html>';

	app.get('/', function(req, res){
   		setResHtml(sql, tempo, resql=>{
   		  reo = reo.replace('{${table}}', resql);
   		  res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
   		  res.write(reo, 'utf-8');
   		  res.end();
 		});
	});
	http.listen(8080, function() {
  		console.log('Server running at //localhost:8080/');
	});
}
