

'use strict';

const http = require('http');
const mysql = require('mysql2'); //sql stuff
const browser = require('./testing.js');

const pool = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: 'locks524',
  database: 'songify1_db',
  charset: 'utf8'
});

// sample-metadata:
//   title: Infinite Streaming
//   description: Performs infinite streaming using the streamingRecognize operation with the Cloud Speech API.
//   usage: node infiniteStreaming.js <encoding> <sampleRateHertz> <languageCode> <streamingLimit>
//paste in terminal to use cloud speech: export GOOGLE_APPLICATION_CREDENTIALS="mico.json"

/**
 * Note: Correct microphone settings required: check enclosed link, and make
 * sure the following conditions are met:
 * 1. SoX must be installed and available in your $PATH- it can be found here:
 * http://sox.sourceforge.net/
 * 2. Microphone must be working
 * 3. Encoding, sampleRateHertz, and # of channels must match header of
 * audioInput file you're recording to.
 * 4. Get Node-Record-lpcm16 https://www.npmjs.com/package/node-record-lpcm16
 * More Info: https://cloud.google.com/speech-to-text/docs/streaming-recognize
 * 5. Set streamingLimit in ms. 290000 ms = ~5 minutes.
 * Maximum streaming limit should be 1/2 of SpeechAPI Streaming Limit.
 */
  var song_name = [];
function main(
  encoding = 'LINEAR16',
  sampleRateHertz = 16000,
  languageCode = 'en-US',
  streamingLimit = 290000
) {
  // [START speech_transcribe_infinite_streaming]

  // const encoding = 'LINEAR16';
  // const sampleRateHertz = 16000;
  // const languageCode = 'en-US';
  // const streamingLimit = 10000; // ms - set to low number for demo purposes

  const chalk = require('chalk');
  const {Writable} = require('stream');
  const recorder = require('node-record-lpcm16');

  // Imports the Google Cloud client library
  // Currently, only v1p1beta1 contains result-end-time
  const speech = require('@google-cloud/speech').v1p1beta1;

  const client = new speech.SpeechClient();

  const config = {
    encoding: encoding,
    sampleRateHertz: sampleRateHertz,
    languageCode: languageCode,
  };

  const request = {
    config,
    interimResults: true,
  };

  let recognizeStream = null;
  let restartCounter = 0;
  let audioInput = [];
  let lastAudioInput = [];
  let resultEndTime = 0;
  let isFinalEndTime = 0;
  let finalRequestEndTime = 0;
  let newStream = true;
  let bridgingOffset = 0;
  let lastTranscriptWasFinal = false;

  function startStream() {
    // Clear current audioInput
    audioInput = [];
    // Initiate (Reinitiate) a recognize stream
    recognizeStream = client
      .streamingRecognize(request)
      .on('error', err => {
        if (err.code === 11) {
          // restartStream();
        } else {
          console.error('API request error ' + err);
        }
      })
      .on('data', speechCallback);

    // Restart stream when streamingLimit expires
    setTimeout(restartStream, streamingLimit);
  }

  const speechCallback = stream => {
    // Convert API result end time from seconds + nanoseconds to milliseconds
    resultEndTime =
      stream.results[0].resultEndTime.seconds * 1000 +
      Math.round(stream.results[0].resultEndTime.nanos / 1000000);

    // Calculate correct time based on offset from audio sent twice
    const correctedTime =
      resultEndTime - bridgingOffset + streamingLimit * restartCounter;

    process.stdout.clearLine();
    process.stdout.cursorTo(0);
    let stdoutText = '';
    if (stream.results[0] && stream.results[0].alternatives[0]) {
      stdoutText =
        correctedTime + ': ' + stream.results[0].alternatives[0].transcript;
	song_name = stream.results[0].alternatives[0].transcript;
    }

    if (stream.results[0].isFinal) {
      process.stdout.write(chalk.green(`${stdoutText}\n`));
	console.log("Chosen Song: " + song_name);
	if (song_name == 'mamama Belle'){
		song_name = 'ma-ma-ma Belle';
	}
	if (song_name == "can't get it out of my head"){
		song_name = "cant get it out of my head";
	}
	if (song_name == 'living thing'){
		song_name = 'livin thing';
	}
	if (song_name == 'stepping out'){
		song_name = 'steppin out';
	}
	if (song_name == 'standing in the rain'){
		song_name = 'standin in the rain';
	}
	if (song_name == "the way life's meant to be"){
		song_name = "the way lifes meant to be";
	}
	if (song_name == 'twenty-first century man'){
		song_name = '21st century man';
	}
	//sqlWork();
	browser(song_name);
	recognizeStream.end();	
	recognizeStream.removeListener('data', speechCallback);
        recognizeStream = null;

      isFinalEndTime = resultEndTime;
      lastTranscriptWasFinal = true;
    } else {
      // Make sure transcript does not exceed console character length
      if (stdoutText.length > process.stdout.columns) {
        stdoutText =
          stdoutText.substring(0, process.stdout.columns - 4) + '...';
      }
      process.stdout.write(chalk.red(`${stdoutText}`));
	
      lastTranscriptWasFinal = false;
    }
  };

  const audioInputStreamTransform = new Writable({
    write(chunk, encoding, next) {
      if (newStream && lastAudioInput.length !== 0) {
        // Approximate math to calculate time of chunks
        const chunkTime = streamingLimit / lastAudioInput.length;
        if (chunkTime !== 0) {
          if (bridgingOffset < 0) {
            bridgingOffset = 0;
          }
          if (bridgingOffset > finalRequestEndTime) {
            bridgingOffset = finalRequestEndTime;
          }
          const chunksFromMS = Math.floor(
            (finalRequestEndTime - bridgingOffset) / chunkTime
          );
          bridgingOffset = Math.floor(
            (lastAudioInput.length - chunksFromMS) * chunkTime
          );

          for (let i = chunksFromMS; i < lastAudioInput.length; i++) {
            recognizeStream.write(lastAudioInput[i]);
          }
        }
        newStream = false;
      }

      audioInput.push(chunk);

      if (recognizeStream) {
        recognizeStream.write(chunk);
      }

      next();
    },

    final() {
      if (recognizeStream) {
        recognizeStream.end();
      }
    },
  });

  function restartStream() {
    if (recognizeStream) {
      recognizeStream.end();
      recognizeStream.removeListener('data', speechCallback);
      recognizeStream = null;
    }
    if (resultEndTime > 0) {
      finalRequestEndTime = isFinalEndTime;
    }
    resultEndTime = 0;

    lastAudioInput = [];
    lastAudioInput = audioInput;

    restartCounter++;

    if (!lastTranscriptWasFinal) {
      process.stdout.write('\n');
    }
    process.stdout.write(
      chalk.yellow(`${streamingLimit * restartCounter}: RESTARTING REQUEST\n`)
    );

    newStream = true;

    startStream();
  }
  // Start recording and send the microphone input to the Speech API
  recorder
    .record({
      sampleRateHertz: sampleRateHertz,
      threshold: 0, // Silence threshold
      silence: 1000,
      keepSilence: true,
      recordProgram: 'rec', // Try also "arecord" or "sox"
    })
    .stream()
    .on('error', err => {
      console.error('Audio recording error ' + err);
    })
    .pipe(audioInputStreamTransform);

  console.log('');
  console.log('Listening, press Ctrl+C to stop.');
  console.log('');
  console.log('End (ms)       Transcript Results/Status');
  console.log('=========================================================');

  startStream();
  // [END speech_transcribe_infinite_streaming]
}

process.on('unhandledRejection', err => {
  console.error(err.message);
  process.exitCode = 1;
});


const speechTime = function micStream() {
	main(...process.argv.slice(2));
	//return song_name;
}
module.exports = speechTime
//main(...process.argv.slice(2)); //comment and uncomment for testing

function sqlWork(){
	pool.getConnection((err, con)=>{
    		if (err) throw err;
		var songql = 'SELECT album FROM songs WHERE name ='+mysql.escape(song_name)+'';
    		con.query(songql, (err, result)=>{
			if (result[0] == null) {
				console.log("Song not in database!");
				con.release();
			}
			else {getAlbSongs(result[0].album);}
    		});
	});	
}

function getAlbSongs(value){
	var alb_name = value;
	
	pool.getConnection((err, con)=>{
    		if (err) throw err;
		
		con.query("SELECT name FROM songs WHERE album = "+mysql.escape(alb_name), function (err, res) {
			if (err) throw err;
			console.log("Songs in same album as " + song_name);
			console.log(res);
		});
		
    		con.query("SELECT bpm from songs WHERE name = " + mysql.escape(song_name), function (err, beats) {
			if (err) throw err;
			getBpmSongs(beats[0].bpm);
		});
		con.query("SELECT notekey FROM songs WHERE name = " +mysql.escape(song_name), function(err, theKey) {
			if (err) throw err;
			getKeySongs(theKey[0].notekey);
		});
	});
}

function getBpmSongs(val){
	var sped = val;
	var low = Number(sped) - 5;
	var high = Number(sped) + 5;

	var bpmsql ='SELECT name FROM songs WHERE bpm BETWEEN ' + mysql.escape(low) +' AND ' + mysql.escape(high)+' ORDER BY name';
	pool.getConnection((err, con)=>{
		con.query(bpmsql, (err, reso)=>{
			if (err) throw err;
			console.log("Songs with similar tempos as " + song_name);
			console.log(reso);
    		});
	});
}

function getKeySongs(v){
	var keynote = v;

	var keyql = 'SELECT name FROM songs WHERE notekey = ' + mysql.escape(keynote)+' ORDER BY name';
	pool.getConnection((err, con)=>{
		con.query(keyql, (err, keyResult)=>{
			if (err) throw err;
			console.log("Songs in same key as " + song_name);
			console.log(keyResult);
		});
	});
}