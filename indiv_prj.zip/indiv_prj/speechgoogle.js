/**
 * This application demonstrates how to perform basic recognize operations with
 * with the Google Cloud Speech API.
 *
 * For more information, see the README.md under /speech and the documentation
 * at https://cloud.google.com/speech/docs.
 * export GOOGLE_APPLICATION_CREDENTIALS="mico.json"
 */

'use strict';

// sample-metadata:
//   title: Microphone stream
//   description: Streams audio input from microphone, translates to text.
//   usage: node MicrophoneStream.js <encoding> <sampleRateHertz> <languageCode>

/**
 * Note: Correct microphone settings is required: check enclosed link, and make
 * sure the following conditions are met:
 * 1. SoX must be installed and available in your $PATH- it can be found here:
 * http://sox.sourceforge.net/
 * 2. Microphone must be working
 * 3. Encoding, sampleRateHertz, and # of channels must match header of audio file you're
 * recording to.
 * 4. Get Node-Record-lpcm16 https://www.npmjs.com/package/node-record-lpcm16
 * More Info: https://cloud.google.com/speech-to-text/docs/streaming-recognize
 */

var song_name = [];
function main(
  encoding = 'LINEAR16',
  sampleRateHertz = 16000,
  languageCode = 'en-US'
) {
  // [START micStreamRecognize]
  const recorder = require('node-record-lpcm16');

  // Imports the Google Cloud client library
  const speech = require('@google-cloud/speech');

  /**
   * TODO(developer): Uncomment the following lines before running the sample.
   */
  // const encoding = 'LINEAR16';
  // const sampleRateHertz = 16000;
  // const languageCode = 'en-US';

  const config = {
    encoding: encoding,
    sampleRateHertz: sampleRateHertz,
    languageCode: languageCode,
  };

  const request = {
    config,
    interimResults: false, //Get interim results from stream
  };

  // Creates a client
  const client = new speech.SpeechClient();

  // Create a recognize stream
  const recognizeStream = client
    .streamingRecognize(request)
    .on('error', console.error)
    .on('data', data =>
	//console.log(data.results[0]),
	console.log("Transcription: " + data.results[0].alternatives[0].transcript)
      /*process.stdout.write(
        data.results[0] && data.results[0].alternatives[0]
          ? `Transcription: ${data.results[0].alternatives[0].transcript}\n`
          : '\n\nReached transcription time limit, press Ctrl+C\n'
      )*/
    )
    /*.on('data', setSong(data.results[0].alternatives[0].transcript))*/;
   //.pipe(setSong(recognizeStream.data.results[0].alternatives[0].transcript));

  // Start recording and send the microphone input to the Speech API
  recorder
    .record({
      sampleRateHertz: sampleRateHertz,
      threshold: 0, //silence threshold
      recordProgram: 'rec', // Try also "arecord" or "sox"
      silence: '5.0', //seconds of silence before ending
    })
    .stream()
    .on('error', console.error)
    .pipe(recognizeStream/*, setSong(recognizeStream.data.results[0].alternatives[0].transcript)*/);

  console.log('Listening, press Ctrl+C to stop.');
  // [END micStreamRecognize]
  //setSong(recognizeStream.data.results[0].alternatives[0].transcript);
}

function setSong(val){
song_name = val;
console.log("Song name: " + song_name);
}

process.on('unhandledRejection', err => {
  console.error(err.message);
  process.exitCode = 1;
});

main(...process.argv.slice(2));