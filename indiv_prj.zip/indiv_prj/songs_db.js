var mysql = require('mysql2');
const prompt = require("prompt-sync")();

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "locks524",
  database: "songify1_db"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

  var song_name = prompt("Pick a song: ");
  console.log(`You picked ${song_name}`);
  var alb = [];
  var sped = [];
  var songkey = [];
  var add = [];
 
  con.query("SELECT album FROM songs WHERE name = " + mysql.escape(song_name), function (err, resulto)  {
	if (resulto[0] == null) {
		console.log("Song not in database! Would You Like to add it?");
		add = prompt("(y/n): ");

		if (add == "n"){
			con.end(function(err) {

 			});
 		} else addSong();
	}
	else {
		console.log("Album: " + resulto[0].album);
		setValue(resulto[0].album);
	}
  });

  function addSong() {
	alb = prompt("Enter the album: ");
	sped = prompt("Enter the tempo: ");
	songkey = prompt("Enter the key: ");
	var records = [
		[song_name, alb, sped, songkey]
	];
	con.query("INSERT INTO songs (name, album, bpm, notekey) VALUES ?", [records], function (err) {
		if (err) throw err;
		console.log("Song Added!");
	});
	con.end(function(err) {

 	});
  }

  function setValue(value) {
	alb = value;

	con.query("SELECT name FROM songs WHERE album = " + mysql.escape(alb), function (err, result) {
  		if (err) throw err;
		console.log("Songs in the same album as " + song_name + ":");
 		console.log(result);
  	});

	con.query("SELECT bpm from songs WHERE name = " + mysql.escape(song_name), function (err, beats) {
		if (err) throw err;
		console.log("BPM: " + beats[0].bpm);
		setSped(beats[0].bpm);
	});	

	function setSped(val){
		sped = val;

		var low = Number(sped) - 5;
		var high = Number(sped) + 5;
		
		con.query("SELECT name FROM songs WHERE bpm BETWEEN " + mysql.escape(low) +" AND " + mysql.escape(high), function (err, tempos) {
			if (err) throw err;
			console.log("Songs with similar tempos as " + song_name + ":");
			console.log(tempos);
		});

	}

	con.query("SELECT notekey FROM songs WHERE	name = " + mysql.escape(song_name), function (err, keys) {
		if (err) throw err;
		console.log("Song Key: " + keys[0].notekey);
		setKey(keys[0].notekey);
	});

	function setKey(x){
		theKey = x;
		con.query("SELECT name FROM songs WHERE notekey = " + mysql.escape(theKey), function (err, keeys) {
			if (err) throw err;
			console.log("Songs in the same key as " + song_name + ":");
			console.log(keeys);
		});

		con.end(function(err) {
		
 	 	});
	}

	
  }
 
});
/*For html use*/
function getSongs() { 
	document.getElementById("test").innerHTML = "Accessed";
	const song_name = document.getElementById("entry").value;
	document.getElementById("Sim").innerHTML = "Songs in the same album as " + song_name + ":";

	con.connect(function (err) {
	if (err) {
		document.getElementById("result").innerHTML = "ERROR";
	}	

	con.query("SELECT album FROM songs WHERE name = " + mysql.escape(song_name), function (err, resulto)  {
		if (resulto[0] == null) {
			console.log("Song not in database!");
			document.getElementById("Sim").innerHTML = "Song not in database!";
			con.end(function(err) {

 			 });
		}
		else {
			var alb = resulto[0].album;
		}

	});

	con.query("SELECT name FROM songs WHERE album = " + mysql.escape(alb), function (err, result) {
  		if (err) throw err;
		document.getElementById("Sim").innerHTML = "Songs in the same album as " + song_name + ":";
 		document.getElementById("result").innerHTML = result;
		
  	});
	con.end(function(err) {

 	});

	});
}


/*con.query("SELECT name, album, bpm, notekey FROM songs", function (err, result, fields) {
	if (err) throw err;
	console.log(result);
 }); */

/*con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  con.query("CREATE DATABASE mysongify_db", function (err, result) {
    if (err) throw err;
    console.log("Database created");
  });
});*/

/*con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "CREATE TABLE songs (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), album VARCHAR(255))";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table Created");
  });
});*/

/*var sql = "INSERT INTO songs (name, album) VALUES ?";
  var values = [
	['Mr. Blue Sky', 'Out of the Blue'],
	find the list on github
  ];
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });*/

/*var sql = "ALTER TABLE songs add column (key  varchar(255))";
  con.query(sql, function (err, result) {
	if (err) throw err;
	console.log("key added");
  });*/

/*var sql = "INSERT INTO songs (bpm) VALUES ?";
  var values = [
	[180], 
	
  ];
  con.query(sql, [values], function (err, result) {
	if (err) throw err;
	console.log("records added: " + result.affectedRows);
  });*/
