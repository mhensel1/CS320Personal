const http = require('http');
const mysql = require('mysql2');
const prompt = require("prompt-sync")();
const speech = require('./speechstream.js');
var express = require('express');
const app = express();
/*var server = http.createServer(app);
//const browse = require('./testing.js');

app.use(express.bodyParser());		//doesn't recognize app
app.post('/', function(req, res) {
	console.log(req.body);
	res.send(200);
});

server.listen(process.env.PORT, process.env.IP);*/

var browsy = '<html><head><title>Songify Suggester</title></head><body>Welcome to Songify<input type="button" onclick="speech();" value="Start Mic" /></body></html>';
browserTime();

function browserTime(){
	const server = http.createServer((req, res)=>{
   		  res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
   		  res.write(browsy, 'utf-8');
   		  res.end();
	});

	server.listen(8081, ()=>{
  		console.log('Server running at //localhost:8081/');
	});
}
