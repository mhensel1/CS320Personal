var express = require('express');
var app = express();
app.get('/entersong', function(req, res){
	var mySong = req.query.song;
	res.send('The song: ' +song);
});
app.listen(3000, ()=>{
	console.log('Server running at //localhost:3000/');
});




function getSongs() {
	const songs_name = document.getElementById("entry");
	document.getElementById("Sim").innerHTML = "Song not in database!";
	document.getElementById("result").innerHTML = song_name;
}